const fs = require('fs/promises');
const path = require('path');
const crypto = require('crypto');

const dbPath = path.join(__dirname, 'database.json');

// Funções auxiliares para ler e escrever no arquivo JSON
const readData = async () => {
    try {
        const data = await fs.readFile(dbPath, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        // Se o arquivo não existir, cria uma estrutura inicial
        return { users: [], offers: [] };
    }
};

const writeData = async (data) => {
    await fs.writeFile(dbPath, JSON.stringify(data, null, 2));
};

// Objeto que exporta funções que simulam as queries do banco
module.exports = {
    // Funções de Usuário
    async findUserByEmail(email) {
        const db = await readData();
        return db.users.find(user => user.email === email);
    },
    async createUser({ fullname, email, hashedPassword }) {
        const db = await readData();
        const newUser = {
            id: crypto.randomUUID(),
            fullname,
            email,
            password: hashedPassword,
            created_at: new Date().toISOString()
        };
        db.users.push(newUser);
        await writeData(db);
        return newUser;
    },
    async findUserById(id) {
        const db = await readData();
        return db.users.find(user => user.id === id);
    },

    // Funções de Oferta
    async createOffer({ userId, offerType, title, description }) {
        const db = await readData();
        const newOffer = {
            id: crypto.randomUUID(),
            user_id: userId,
            offer_type: offerType,
            title,
            description,
            created_at: new Date().toISOString()
        };
        db.offers.push(newOffer);
        await writeData(db);
        return newOffer;
    },
    async getAllOffers() {
        const db = await readData();
        // Simula o JOIN
        return db.offers.map(offer => {
            const author = db.users.find(user => user.id === offer.user_id);
            return {
                ...offer,
                author_name: author ? author.fullname : 'Usuário Desconhecido'
            };
        }).sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
    },
    async getOfferById(id) {
        const db = await readData();
        const offer = db.offers.find(o => o.id === id);
        if (!offer) return null;
        const author = db.users.find(user => user.id === offer.user_id);
        return {
            ...offer,
            author_name: author ? author.fullname : 'Usuário Desconhecido',
            author_email: author ? author.email : 'email@desconhecido.com'
        };
    },
    async getMyOffers(userId) {
        const db = await readData();
        return db.offers
            .filter(offer => offer.user_id === userId)
            .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
    },
    async deleteOffer(offerId, userId) {
        const db = await readData();
        const offerIndex = db.offers.findIndex(o => o.id === offerId);

        if (offerIndex === -1) throw new Error('Oferta não encontrada');
        if (db.offers[offerIndex].user_id !== userId) throw new Error('Acesso negado');
        
        db.offers.splice(offerIndex, 1);
        await writeData(db);
        return { message: 'Oferta deletada com sucesso!' };
    }
};