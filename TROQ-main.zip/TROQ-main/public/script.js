document.addEventListener('DOMContentLoaded', () => {
    // --- SELETORES DE ELEMENTOS ---
    const signupForm = document.getElementById('signup-form');
    const loginForm = document.getElementById('login-form');
    const offerForm = document.getElementById('offer-form');
    const mainMessageDiv = document.getElementById('message');

    // --- FUNÇÕES AUXILIARES ---
    const showMessage = (form, message, type) => {
        const messageDiv = form.querySelector('#message') || mainMessageDiv;
        if (messageDiv) {
            messageDiv.textContent = message;
            messageDiv.className = `message ${type}`;
        }
    };

    // --- INICIALIZAÇÃO DE COMPONENTES (SWIPER) ---
    if (document.querySelector('.category-swiper')) {
        const categorySwiper = new Swiper('.category-swiper', {
            slidesPerView: 'auto',
            spaceBetween: 10,
            navigation: {
                nextEl: '.swiper-button-next',
                prevEl: '.swiper-button-prev',
            },
        });
    }

    // --- LÓGICA DOS FORMULÁRIOS ---
    if (signupForm) {
        signupForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const fullname = document.getElementById('fullname').value;
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm-password').value;
            if (password !== confirmPassword) {
                showMessage(signupForm, 'As senhas não coincidem!', 'error');
                return;
            }
            try {
                const res = await fetch('/register', {
                    method: 'POST', headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ fullname, email, password }),
                });
                const data = await res.json();
                if (res.ok) {
                    showMessage(signupForm, data.message, 'success');
                    signupForm.reset();
                    setTimeout(() => window.location.href = '/login.html', 2000);
                } else {
                    showMessage(signupForm, data.message, 'error');
                }
            } catch (error) {
                showMessage(signupForm, 'Ocorreu um erro na comunicação com o servidor.', 'error');
            }
        });
    }

    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            try {
                const res = await fetch('/login', {
                    method: 'POST', headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ email, password }),
                });
                const data = await res.json();
                if (res.ok) {
                    showMessage(loginForm, data.message, 'success');
                    if (data.redirectUrl) {
                        setTimeout(() => { window.location.href = data.redirectUrl; }, 1500);
                    }
                } else {
                    showMessage(loginForm, data.message, 'error');
                }
            } catch (error) {
                showMessage(loginForm, 'Ocorreu um erro na comunicação com o servidor.', 'error');
            }
        });
    }

    if (offerForm) {
        offerForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const offerType = document.getElementById('offer-type').value;
            const title = document.getElementById('title').value;
            const description = document.getElementById('description').value;
            try {
                const res = await fetch('/api/offers', {
                    method: 'POST', headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ offerType, title, description }),
                });
                const data = await res.json();
                if (res.ok) {
                    showMessage(offerForm, data.message, 'success');
                    offerForm.reset();
                } else {
                    showMessage(offerForm, data.message, 'error');
                }
            } catch (error) {
                showMessage(offerForm, 'Ocorreu um erro na comunicação com o servidor.', 'error');
            }
        });
    }

    // --- FUNÇÕES DE BUSCA DE DADOS (FETCH) ---
    const fetchAndDisplayOffers = async () => {
        const offersListDiv = document.getElementById('offers-list');
        if (!offersListDiv) return;

        try {
            const res = await fetch('/api/offers');
            const offers = await res.json();

            if (!res.ok) {
                offersListDiv.innerHTML = '<p>Erro ao carregar as ofertas.</p>';
                return;
            }

            if (offers.length === 0) {
                offersListDiv.innerHTML = `
                    <div class="offer-card placeholder">
                        <div class="placeholder-img"></div>
                        <div class="placeholder-text"></div>
                        <div class="placeholder-text short"></div>
                    </div>
                    <div class="offer-card placeholder">
                        <div class="placeholder-img"></div>
                        <div class="placeholder-text"></div>
                        <div class="placeholder-text short"></div>
                    </div>
                    <div class="offer-card placeholder">
                        <div class="placeholder-img"></div>
                        <div class="placeholder-text"></div>
                        <div class="placeholder-text short"></div>
                    </div>
                `;
                return;
            }

            offersListDiv.innerHTML = '';
            offers.forEach(offer => {
                const offerLink = document.createElement('a');
                offerLink.href = `/offer.html?id=${offer.id}`;
                offerLink.className = 'offer-card-link';
                offerLink.style.textDecoration = 'none';
                offerLink.innerHTML = `<div class="offer-card"><span class="offer-type offer-type-${offer.offer_type}">${offer.offer_type}</span><h3>${offer.title}</h3><p>${offer.description || 'Clique para ver mais detalhes...'}</p><div class="author">Publicado por: <strong>${offer.author_name}</strong></div></div>`;
                offersListDiv.appendChild(offerLink);
            });
        } catch (error) {
            console.error("Erro no fetch das ofertas:", error);
            offersListDiv.innerHTML = '<p>Erro ao conectar com o servidor.</p>';
        }
    };

    const fetchOfferDetails = async () => {
        const offerDetailContainer = document.getElementById('offer-detail-container');
        if (!offerDetailContainer) return;
        const urlParams = new URLSearchParams(window.location.search);
        const offerId = urlParams.get('id');
        if (!offerId) { offerDetailContainer.innerHTML = '<h1>Erro: ID da oferta não fornecido.</h1>'; return; }
        try {
            const res = await fetch(`/api/offers/${offerId}`);
            const offer = await res.json();
            if (!res.ok) { offerDetailContainer.innerHTML = `<h1>Erro: ${offer.message}</h1>`; return; }
            const formattedDate = new Date(offer.created_at).toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' });
            offerDetailContainer.innerHTML = `<span class="offer-type offer-type-${offer.offer_type}">${offer.offer_type}</span><h1>${offer.title}</h1><div class="author-info">Publicado por <strong>${offer.author_name}</strong> em ${formattedDate}<br>Contato: <a href="mailto:${offer.author_email}">${offer.author_email}</a></div><p class="description">${offer.description || 'Nenhuma descrição detalhada fornecida.'}</p>`;
        } catch (error) {
            console.error('Erro ao buscar detalhes da oferta:', error);
            offerDetailContainer.innerHTML = '<h1>Erro ao conectar com o servidor.</h1>';
        }
    };

    const fetchMyOffers = async () => {
        const myOffersListDiv = document.getElementById('my-offers-list');
        if (!myOffersListDiv) return;
        try {
            const res = await fetch('/api/my-offers');
            const offers = await res.json();
            if (offers.length === 0) { myOffersListDiv.innerHTML = '<p>Você ainda não publicou nenhuma oferta.</p>'; return; }
            myOffersListDiv.innerHTML = '';
            offers.forEach(offer => {
                const card = document.createElement('div');
                card.className = 'offer-card';
                card.innerHTML = `<span class="offer-type offer-type-${offer.offer_type}">${offer.offer_type}</span><h3>${offer.title}</h3><p>${offer.description || ''}</p><div class="card-actions"><button class="delete-btn" data-id="${offer.id}">Excluir</button></div>`;
                myOffersListDiv.appendChild(card);
            });
        } catch (error) {
            myOffersListDiv.innerHTML = '<p>Erro ao carregar suas ofertas.</p>';
        }
    };

    const updateUserNav = async () => {
        const authLinksContainer = document.getElementById('auth-links-container');
        if (!authLinksContainer) return;
        try {
            const res = await fetch('/api/auth/status');
            const data = await res.json();
            if (data.loggedIn) {
                authLinksContainer.innerHTML = `<span class="welcome-message">Olá, ${data.user.fullname}!</span><a href="/dashboard_interno.html" class="auth-link">Criar Oferta</a><a href="/my-offers.html" class="auth-link">Minhas Ofertas</a><a href="/logout" class="auth-link">Sair</a>`;
            } else {
                authLinksContainer.innerHTML = `<a href="/login.html" class="auth-link">Login</a><a href="/cadastro.html" class="auth-link">Cadastro</a>`;
            }
        } catch (error) {
            console.error('Erro ao verificar status de autenticação:', error);
            authLinksContainer.innerHTML = `<a href="/login.html" class="auth-link">Login</a><a href="/cadastro.html" class="auth-link">Cadastro</a>`;
        }
    };

    // --- EVENT LISTENER GLOBAL ---
    document.body.addEventListener('click', async (e) => {
        if (e.target.classList.contains('delete-btn')) {
            const offerId = e.target.getAttribute('data-id');
            if (confirm('Tem certeza que deseja excluir esta oferta? Esta ação não pode ser desfeita.')) {
                try {
                    const res = await fetch(`/api/offers/${offerId}`, { method: 'DELETE' });
                    const data = await res.json();
                    if (res.ok) {
                        alert(data.message);
                        fetchMyOffers();
                    } else {
                        alert(`Erro: ${data.message}`);
                    }
                } catch (err) {
                    alert('Erro de comunicação com o servidor.');
                }
            }
        }
    });

    // --- CHAMADA DAS FUNÇÕES AO CARREGAR A PÁGINA ---
    updateUserNav();
    fetchAndDisplayOffers();
    fetchOfferDetails();
    fetchMyOffers();
});