# TODO List for Updating Dashboard Images

- [x] Remove duplicate nested HTML structure inside offers-list div
- [x] Update img src for second offer-card to "icon/chef.jpg"
- [x] Update img src for third offer-card to "icon/fax.jpg"
- [x] Update alt attributes for the images to match the new sources
- [x] Verify the HTML structure is correct after edits
