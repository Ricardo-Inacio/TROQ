require('dotenv').config();

const express = require('express');
const { Pool } = require('pg');
const bcrypt = require('bcrypt');
const path = require('path');
const session = require('express-session');

// --- SELETOR DE BANCO DE DADOS ---
const db = process.env.DB_MODE === 'json'
    ? require('./db_json')
    : require('./db_postgres');

const app = express();
const PORT = 3001;

// --- Middlewares ---
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
    secret: process.env.SESSION_SECRET,
    resave: false, saveUninitialized: false,
    cookie: { secure: false, maxAge: 3600000 }
}));

const isAuthenticated = (req, res, next) => {
    if (req.session.user) { next(); } 
    else { res.redirect('/login.html'); }
};

// --- ROTAS DA API ---
app.get('/api/auth/status', (req, res) => {
    if (req.session.user) { res.status(200).json({ loggedIn: true, user: req.session.user }); } 
    else { res.status(200).json({ loggedIn: false }); }
});

app.post('/register', async (req, res) => {
    try {
        const { fullname, email, password } = req.body;
        const hashedPassword = await bcrypt.hash(password, 10);
        await db.createUser({ fullname, email, hashedPassword });
        res.status(201).json({ message: 'Usuário cadastrado com sucesso!' });
    } catch (error) {
        console.error("Erro no registro:", error);
        res.status(500).json({ message: 'Erro interno no servidor.' });
    }
});

app.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;
        const user = await db.findUserByEmail(email);
        if (!user || !await bcrypt.compare(password, user.password)) {
            return res.status(401).json({ message: 'Email ou senha inválidos.' });
        }
        req.session.user = { id: user.id, fullname: user.fullname, email: user.email };
        res.status(200).json({ message: `Login bem-sucedido!`, redirectUrl: '/home.html' }); 
    } catch (error) {
        console.error("Erro no login:", error);
        res.status(500).json({ message: 'Erro interno no servidor.' });
    }
});

app.get('/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) return res.status(500).send('Não foi possível fazer logout.');
        res.redirect('/login.html');
    });
});

app.post('/api/offers', isAuthenticated, async (req, res) => {
    try {
        const { offerType, title, description } = req.body;
        const userId = req.session.user.id;
        const newOffer = await db.createOffer({ userId, offerType, title, description });
        res.status(201).json({ message: 'Oferta publicada com sucesso!', offerId: newOffer.id });
    } catch (error) {
        console.error("Erro ao criar oferta:", error);
        res.status(500).json({ message: 'Erro interno no servidor.' });
    }
});

app.get('/api/offers', async (req, res) => {
    try {
        const offers = await db.getAllOffers();
        res.status(200).json(offers);
    } catch (error) {
        console.error("Erro ao buscar ofertas:", error);
        res.status(500).json({ message: 'Erro interno no servidor.' });
    }
});

app.get('/api/offers/:id', async (req, res) => {
    try {
        const offer = await db.getOfferById(req.params.id);
        if (!offer) return res.status(404).json({ message: 'Oferta não encontrada.' });
        res.status(200).json(offer);
    } catch (error) {
        console.error("Erro ao buscar oferta por ID:", error);
        res.status(500).json({ message: 'Erro interno no servidor.' });
    }
});

app.get('/api/my-offers', isAuthenticated, async (req, res) => {
    try {
        const offers = await db.getMyOffers(req.session.user.id);
        res.status(200).json(offers);
    } catch (error) {
        console.error("Erro ao buscar 'minhas ofertas':", error);
        res.status(500).json({ message: 'Erro interno no servidor.' });
    }
});

app.delete('/api/offers/:id', isAuthenticated, async (req, res) => {
    try {
        await db.deleteOffer(req.params.id, req.session.user.id);
        res.status(200).json({ message: 'Oferta deletada com sucesso!' });
    } catch (error) {
        console.error("Erro ao deletar oferta:", error);
        const message = error.message === 'Acesso negado' ? 'Acesso negado' : 'Erro interno no servidor.';
        res.status(error.message === 'Acesso negado' ? 403 : 500).json({ message });
    }
});

// --- NOVAS ROTAS DE CONTA ---
app.get('/api/account', isAuthenticated, (req, res) => {
    // Retorna os dados do usuário logado que já estão na sessão
    res.status(200).json(req.session.user);
});

app.put('/api/account', isAuthenticated, async (req, res) => {
    try {
        const { fullname, email } = req.body;
        const userId = req.session.user.id;

        if (!fullname || !email) {
            return res.status(400).json({ message: 'Nome e email são obrigatórios.' });
        }

        const updatedUser = await db.updateUser(userId, { fullname, email });

        // Atualiza a sessão com os novos dados
        req.session.user.fullname = updatedUser.fullname;
        req.session.user.email = updatedUser.email;

        res.status(200).json({ message: 'Perfil atualizado com sucesso!', user: req.session.user });

    } catch (error) {
        console.error("Erro ao atualizar perfil:", error);
        res.status(500).json({ message: 'Erro interno no servidor.' });
    }
});

// --- ROTAS PARA SERVIR PÁGINAS HTML (ATUALIZADAS) ---
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'public', 'dashboard.html')));
app.get('/dashboard.html', (req, res) => res.sendFile(path.join(__dirname, 'public', 'dashboard.html')));
app.get('/index.html', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.get('/login.html', (req, res) => res.sendFile(path.join(__dirname, 'public', 'login.html')));
app.get('/offer.html', (req, res) => res.sendFile(path.join(__dirname, 'public', 'offer.html')));
app.get('/create-offer.html', isAuthenticated, (req, res) => res.sendFile(path.join(__dirname, 'public', 'create-offer.html')));
app.get('/my-offers.html', isAuthenticated, (req, res) => res.sendFile(path.join(__dirname, 'public', 'my-offers.html')));
app.get('/home.html', isAuthenticated, (req, res) => res.sendFile(path.join(__dirname, 'public', 'home.html')));
// NOVA ROTA
app.get('/account.html', isAuthenticated, (req, res) => res.sendFile(path.join(__dirname, 'public', 'account.html')));

app.listen(PORT, () => {
    console.log(`🚀 Servidor rodando em http://localhost:${PORT} no modo '${process.env.DB_MODE}'`);
});