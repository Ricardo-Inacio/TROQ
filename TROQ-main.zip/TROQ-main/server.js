// server.js (VERSÃO FINAL COM TODAS AS FUNCIONALIDADES E CORREÇÕES)

require('dotenv').config();

const express = require('express');
const { Pool } = require('pg');
const bcrypt = require('bcrypt');
const path = require('path');
const session = require('express-session');

const app = express();
const PORT = 3001;

// --- Middlewares ---
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.use(session({
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    cookie: { 
        secure: false, 
        maxAge: 3600000 // Sessão dura 1 hora
    } 
}));

// --- Conexão com o Banco de Dados ---
const pool = new Pool({
    host: process.env.DB_HOST,
    port: process.env.DB_PORT,
    user: process.env.DB_USER,
    database: process.env.DB_DATABASE,
    password: process.env.DB_PASSWORD,
    ssl: true,
});

// --- Middleware de Autenticação ---
const isAuthenticated = (req, res, next) => {
    if (req.session.user) {
        next();
    } else {
        res.redirect('/login.html');
    }
};

// --- ROTAS DA API ---

// ROTA PARA VERIFICAR O STATUS DA AUTENTICAÇÃO
app.get('/api/auth/status', (req, res) => {
    if (req.session.user) {
        res.status(200).json({ loggedIn: true, user: req.session.user });
    } else {
        res.status(200).json({ loggedIn: false });
    }
});

// ROTA DE CADASTRO
app.post('/register', async (req, res) => {
    const { fullname, email, password } = req.body;
    if (!fullname || !email || !password) {
        return res.status(400).json({ message: 'Todos os campos são obrigatórios!' });
    }
    try {
        const hashedPassword = await bcrypt.hash(password, 10);
        await pool.query(`INSERT INTO users (fullname, email, password) VALUES ($1, $2, $3)`, [fullname, email, hashedPassword]);
        res.status(201).json({ message: 'Usuário cadastrado com sucesso!' });
    } catch (error) {
        if (error.code === '23505') {
            return res.status(409).json({ message: 'Este e-mail já está em uso.' });
        }
        console.error("Erro ao registrar usuário:", error);
        res.status(500).json({ message: 'Ocorreu um erro no servidor.' });
    }
});

// ROTA DE LOGIN (COM REDIRECIONAMENTO CORRIGIDO)
app.post('/login', async (req, res) => {
    const { email, password } = req.body;
    try {
        const result = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
        if (result.rows.length === 0) {
            return res.status(401).json({ message: 'Email ou senha inválidos.' });
        }
        const user = result.rows[0];
        const isPasswordValid = await bcrypt.compare(password, user.password);
        if (!isPasswordValid) {
            return res.status(401).json({ message: 'Email ou senha inválidos.' });
        }
        req.session.user = { id: user.id, fullname: user.fullname, email: user.email };
        res.status(200).json({ message: `Login bem-sucedido!`, redirectUrl: '/dashboard.html' }); // <-- CORREÇÃO APLICADA AQUI
    } catch (error) {
        console.error("Erro ao fazer login:", error);
        res.status(500).json({ message: 'Ocorreu um erro no servidor.' });
    }
});

// ROTA DE LOGOUT
app.get('/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) return res.status(500).send('Não foi possível fazer logout.');
        res.redirect('/login.html');
    });
});

// ROTA PARA CRIAR OFERTA
app.post('/api/offers', isAuthenticated, async (req, res) => {
    const { offerType, title, description } = req.body;
    const userId = req.session.user.id;
    if (!offerType || !title) {
        return res.status(400).json({ message: 'O tipo e o título da oferta são obrigatórios.' });
    }
    try {
        const result = await pool.query(`INSERT INTO offers (user_id, offer_type, title, description) VALUES ($1, $2, $3, $4) RETURNING id`, [userId, offerType, title, description]);
        res.status(201).json({ message: 'Oferta publicada com sucesso!', offerId: result.rows[0].id });
    } catch (error) {
        console.error("Erro ao criar oferta:", error);
        res.status(500).json({ message: 'Ocorreu um erro no servidor.' });
    }
});

// ROTA PARA LER TODAS AS OFERTAS
app.get('/api/offers', async (req, res) => {
    try {
        const result = await pool.query(`SELECT o.id, o.offer_type, o.title, o.description, o.created_at, u.fullname AS author_name FROM offers o JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC`);
        res.status(200).json(result.rows);
    } catch (error) {
        console.error("Erro ao buscar ofertas:", error);
        res.status(500).json({ message: 'Ocorreu um erro no servidor.' });
    }
});

// ROTA PARA LER UMA OFERTA
app.get('/api/offers/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const result = await pool.query(`SELECT o.id, o.offer_type, o.title, o.description, o.created_at, u.fullname AS author_name, u.email AS author_email FROM offers o JOIN users u ON o.user_id = u.id WHERE o.id = $1`, [id]);
        if (result.rows.length === 0) {
            return res.status(404).json({ message: 'Oferta não encontrada.' });
        }
        res.status(200).json(result.rows[0]);
    } catch (error) {
        console.error("Erro ao buscar a oferta:", error);
        res.status(500).json({ message: 'Ocorreu um erro no servidor.' });
    }
});

// ROTA PARA BUSCAR MINHAS OFERTAS
app.get('/api/my-offers', isAuthenticated, async (req, res) => {
    try {
        const result = await pool.query('SELECT * FROM offers WHERE user_id = $1 ORDER BY created_at DESC', [req.session.user.id]);
        res.status(200).json(result.rows);
    } catch (error) {
        console.error("Erro ao buscar 'minhas ofertas':", error);
        res.status(500).json({ message: 'Erro no servidor.' });
    }
});

// ROTA PARA DELETAR OFERTA
app.delete('/api/offers/:id', isAuthenticated, async (req, res) => {
    const userId = req.session.user.id;
    const { id: offerId } = req.params;
    try {
        const checkResult = await pool.query('SELECT user_id FROM offers WHERE id = $1', [offerId]);
        if (checkResult.rows.length === 0) return res.status(404).json({ message: 'Oferta não encontrada.' });
        if (checkResult.rows[0].user_id !== userId) return res.status(403).json({ message: 'Acesso negado.' });
        await pool.query('DELETE FROM offers WHERE id = $1', [offerId]);
        res.status(200).json({ message: 'Oferta deletada com sucesso!' });
    } catch (error) {
        console.error("Erro ao deletar oferta:", error);
        res.status(500).json({ message: 'Erro no servidor.' });
    }
});


// --- ROTAS PARA SERVIR PÁGINAS HTML ---
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'public', 'dashboard.html')));
app.get('/dashboard.html', (req, res) => res.sendFile(path.join(__dirname, 'public', 'dashboard.html')));
app.get('/cadastro.html', (req, res) => res.sendFile(path.join(__dirname, 'public', 'cadastro.html')));
app.get('/login.html', (req, res) => res.sendFile(path.join(__dirname, 'public', 'login.html')));
app.get('/offer.html', (req, res) => res.sendFile(path.join(__dirname, 'public', 'offer.html')));
app.get('/my-offers.html', isAuthenticated, (req, res) => res.sendFile(path.join(__dirname, 'public', 'my-offers.html')));
app.get('/dashboard_interno.html', isAuthenticated, (req, res) => res.sendFile(path.join(__dirname, 'public', 'dashboard_interno.html')));

// --- Inicia o Servidor ---
app.listen(PORT, () => {
    console.log(`🚀 Servidor rodando em http://localhost:${PORT}`);
});