// db_postgres.js (Completo com funções de senha e edição de oferta)

const { Pool } = require('pg');

// Configuração do Pool de Conexão (lê variáveis de ambiente)
const pool = new Pool({
    host: process.env.DB_HOST,
    port: process.env.DB_PORT,
    user: process.env.DB_USER,
    database: process.env.DB_DATABASE,
    password: process.env.DB_PASSWORD,
    ssl: true, // Necessário para Neon e outros bancos na nuvem
});

module.exports = {
    // --- Funções de Usuário ---
    async findUserByEmail(email) {
        // Busca usuário pelo email, incluindo a senha hash para verificação no login
        const result = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
        return result.rows[0]; // Retorna o usuário encontrado ou undefined
    },
    async createUser({ fullname, email, hashedPassword }) {
        // Insere um novo usuário no banco
        const result = await pool.query(
            `INSERT INTO users (fullname, email, password) VALUES ($1, $2, $3) RETURNING id`,
            [fullname, email, hashedPassword]
        );
        return result.rows[0]; // Retorna { id: novo_id }
    },
    async findUserById(id) {
        // Busca usuário pelo ID, mas retorna SEM a senha hash (para segurança)
        const result = await pool.query('SELECT id, fullname, email, avatar_url FROM users WHERE id = $1', [id]);
        return result.rows[0]; // Retorna o usuário encontrado ou undefined
    },
    // Função para buscar usuário incluindo a senha hash (usada na alteração de senha)
    async findUserByIdWithPassword(id) {
        const result = await pool.query('SELECT * FROM users WHERE id = $1', [id]);
        return result.rows[0]; // Retorna todos os campos, incluindo 'password'
    },
    async updateUser(userId, { fullname, email, avatarUrl }) {
        // Atualiza nome, email e avatar_url do usuário
        const result = await pool.query(
            `UPDATE users
             SET fullname = $1, email = $2, avatar_url = $3
             WHERE id = $4
             RETURNING id, fullname, email, avatar_url`, // Retorna os dados atualizados
            [fullname, email, avatarUrl, userId]
        );
        // Verifica se alguma linha foi realmente atualizada
        if (result.rows.length === 0) {
            throw new Error('Usuário não encontrado para atualização');
        }
        return result.rows[0]; // Retorna o usuário atualizado
    },
    // Função para atualizar apenas a senha do usuário
    async updateUserPassword(userId, hashedPassword) {
        const result = await pool.query(
            `UPDATE users SET password = $1 WHERE id = $2 RETURNING id`, // Atualiza a coluna 'password'
            [hashedPassword, userId]
        );
        // Verifica se alguma linha foi atualizada
        if (result.rows.length === 0) {
            throw new Error('Usuário não encontrado para atualização de senha');
        }
        return result.rows[0]; // Confirma que a atualização ocorreu retornando o ID
    },
    // Função para buscar usuários por nome (para a busca de usuários)
    async findUsersByName(searchTerm) {
        if (!searchTerm || searchTerm.trim() === '') {
            return []; // Retorna array vazio se busca for vazia
        }
        const query = `
            SELECT id, fullname, email, avatar_url -- Não retorna a senha
            FROM users
            WHERE fullname ILIKE $1 -- Busca case-insensitive
            ORDER BY fullname ASC;
        `;
        const params = [`%${searchTerm}%`]; // Adiciona curingas
        console.log("Executando busca de usuários:", query, params);
        const result = await pool.query(query, params);
        return result.rows; // Retorna lista de usuários encontrados
    },

    // --- Funções de Oferta ---
    async createOffer({ userId, offerType, title, description, imageUrl }) {
        // Insere uma nova oferta no banco
        const result = await pool.query(
            `INSERT INTO offers (user_id, offer_type, title, description, image_url)
             VALUES ($1, $2, $3, $4, $5) RETURNING id`,
            [userId, offerType, title, description, imageUrl]
        );
        return result.rows[0]; // Retorna { id: novo_id }
    },
    async getAllOffers(searchTerm, category) {
        // Busca todas as ofertas, com filtros opcionais de busca e categoria
        let query = `
            SELECT o.id, o.offer_type, o.title, o.description, o.created_at, o.image_url, u.fullname AS author_name
            FROM offers o
            JOIN users u ON o.user_id = u.id
        `;
        const params = [];
        let paramIndex = 1;
        const conditions = [];

        // Adiciona condição de busca por texto (título ou descrição)
        if (searchTerm) {
            conditions.push(` (o.title ILIKE $${paramIndex} OR o.description ILIKE $${paramIndex}) `);
            params.push(`%${searchTerm}%`);
            paramIndex++;
        }
        // Adiciona condição de filtro por categoria
        if (category) {
            conditions.push(` o.offer_type = $${paramIndex} `);
            params.push(category);
            paramIndex++;
        }
        // Junta as condições com AND se houver mais de uma
        if (conditions.length > 0) {
            query += ' WHERE ' + conditions.join(' AND ');
        }
        query += ` ORDER BY o.created_at DESC`; // Ordena pelas mais recentes

        console.log("Executando query:", query, params);
        const result = await pool.query(query, params);
        return result.rows; // Retorna a lista de ofertas encontradas
    },
    async getOfferById(id) {
        // Busca os detalhes de uma oferta específica pelo ID, juntando com dados do autor
        const result = await pool.query(
            `SELECT o.id, o.offer_type, o.title, o.description, o.created_at, o.image_url, u.fullname AS author_name, u.email AS author_email
             FROM offers o
             JOIN users u ON o.user_id = u.id
             WHERE o.id = $1`,
            [id]
        );
        return result.rows[0]; // Retorna a oferta encontrada ou undefined
    },
     async getOfferByIdAndOwner(offerId, userId) {
        // Busca uma oferta específica APENAS se pertencer ao usuário fornecido
        const result = await pool.query( `SELECT * FROM offers WHERE id = $1 AND user_id = $2`, [offerId, userId] );
        return result.rows[0]; // Retorna a oferta ou undefined
    },
    async getMyOffers(userId) {
        // Busca todas as ofertas pertencentes a um usuário específico
        const result = await pool.query(
            `SELECT id, offer_type, title, description, created_at, image_url
             FROM offers
             WHERE user_id = $1
             ORDER BY created_at DESC`,
            [userId]
        );
        return result.rows; // Retorna a lista de ofertas do usuário
    },
    async updateOffer(offerId, userId, { offerType, title, description, imageUrl }) {
        // Atualiza os dados de uma oferta existente, verificando a propriedade primeiro
        const check = await this.getOfferByIdAndOwner(offerId, userId); // Garante que o usuário é o dono
        if (!check) { throw new Error('Acesso negado ou oferta não encontrada.'); } // Lança erro se não for

        const result = await pool.query(
            `UPDATE offers SET offer_type = $1, title = $2, description = $3, image_url = $4
             WHERE id = $5 RETURNING *`, // Retorna todos os dados da oferta atualizada
            [offerType, title, description, imageUrl, offerId]
        );
        return result.rows[0]; // Retorna a oferta atualizada
    },
    async deleteOffer(offerId, userId) {
        // Deleta uma oferta, verificando a propriedade primeiro
        const checkResult = await pool.query('SELECT user_id FROM offers WHERE id = $1', [offerId]);
        if (checkResult.rows.length === 0) { throw new Error('Oferta não encontrada'); } // Erro se não existir
        if (checkResult.rows[0].user_id !== userId) { throw new Error('Acesso negado'); } // Erro se não for o dono

        const deleteResult = await pool.query('DELETE FROM offers WHERE id = $1', [offerId]); // Executa a deleção
        if (deleteResult.rowCount === 0) { throw new Error('Falha ao deletar a oferta'); } // Erro inesperado
        return { message: 'Oferta deletada com sucesso!' }; // Retorna mensagem de sucesso
    }
};