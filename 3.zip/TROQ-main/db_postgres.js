const { Pool } = require('pg');

const pool = new Pool({
    host: process.env.DB_HOST,
    port: process.env.DB_PORT,
    user: process.env.DB_USER,
    database: process.env.DB_DATABASE,
    password: process.env.DB_PASSWORD,
    ssl: true,
});

module.exports = {
    async findUserByEmail(email) {
        const result = await pool.query('SELECT * FROM users WHERE email = $1', [email]);
        return result.rows[0];
    },
    async createUser({ fullname, email, hashedPassword }) {
        const result = await pool.query(`INSERT INTO users (fullname, email, password) VALUES ($1, $2, $3) RETURNING id`, [fullname, email, hashedPassword]);
        return result.rows[0];
    },
    async findUserById(id) {
        const result = await pool.query('SELECT * FROM users WHERE id = $1', [id]);
        return result.rows[0];
    },
    async createOffer({ userId, offerType, title, description }) {
        const result = await pool.query(`INSERT INTO offers (user_id, offer_type, title, description) VALUES ($1, $2, $3, $4) RETURNING id`, [userId, offerType, title, description]);
        return result.rows[0];
    },
    async getAllOffers() {
        const result = await pool.query(`SELECT o.id, o.offer_type, o.title, o.description, o.created_at, u.fullname AS author_name FROM offers o JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC`);
        return result.rows;
    },
    async getOfferById(id) {
        const result = await pool.query(`SELECT o.id, o.offer_type, o.title, o.description, o.created_at, u.fullname AS author_name, u.email AS author_email FROM offers o JOIN users u ON o.user_id = u.id WHERE o.id = $1`, [id]);
        return result.rows[0];
    },
    async getMyOffers(userId) {
        const result = await pool.query('SELECT * FROM offers WHERE user_id = $1 ORDER BY created_at DESC', [userId]);
        return result.rows;
    },
    async deleteOffer(offerId, userId) {
        const checkResult = await pool.query('SELECT user_id FROM offers WHERE id = $1', [offerId]);
        if (checkResult.rows.length === 0) throw new Error('Oferta não encontrada');
        if (checkResult.rows[0].user_id !== userId) throw new Error('Acesso negado');
        
        await pool.query('DELETE FROM offers WHERE id = $1', [offerId]);
        return { message: 'Oferta deletada com sucesso!' };
    }
};