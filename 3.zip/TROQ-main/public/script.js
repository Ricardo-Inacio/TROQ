document.addEventListener('DOMContentLoaded', () => {
    // --- SELETORES DE ELEMENTOS ---
    const signupForm = document.getElementById('signup-form');
    const loginForm = document.getElementById('login-form');
    const offerForm = document.getElementById('offer-form');
    const accountForm = document.getElementById('account-form');
    const passwordForm = document.getElementById('password-form');
    const mainMessageDiv = document.getElementById('message');
    const themeToggleButton = document.getElementById('theme-toggle');
    const themePlaceholderPublic = document.getElementById('theme-toggle-placeholder-public');

    // --- FUNÇÕES AUXILIARES ---
    const showMessage = (form, message, type) => {
        const messageDiv = form.querySelector('#message') || form.querySelector('#password-message') || mainMessageDiv;
        if (messageDiv) {
            messageDiv.textContent = message;
            messageDiv.className = `message ${type}`;
        }
    };

    // --- LÓGICA DO TEMA CLARO/ESCURO ---
    const currentTheme = localStorage.getItem('theme') || 'light';
    if (currentTheme === 'dark') {
        document.body.classList.add('dark-theme');
    }

    const toggleTheme = () => {
        document.body.classList.toggle('dark-theme');
        let theme = 'light';
        if (document.body.classList.contains('dark-theme')) {
            theme = 'dark';
        }
        localStorage.setItem('theme', theme);
        updateThemeButtons(theme);
    };

    const updateThemeButtons = (theme) => {
        const icon = theme === 'dark' ? '☀️' : '🌙';
        if (themeToggleButton) themeToggleButton.textContent = icon;
        const placeholderButton = themePlaceholderPublic?.querySelector('.theme-toggle-button');
        if (placeholderButton) placeholderButton.textContent = icon;
    };

    // Adiciona listener ao botão principal (se existir)
    if (themeToggleButton) {
        themeToggleButton.addEventListener('click', toggleTheme);
    }

    // Cria e adiciona o botão dinamicamente no placeholder público
    if (themePlaceholderPublic) {
        const button = document.createElement('button');
        button.className = 'theme-toggle-button';
        button.textContent = document.body.classList.contains('dark-theme') ? '☀️' : '🌙';
        button.addEventListener('click', toggleTheme);
        themePlaceholderPublic.appendChild(button);
    }
    // Atualiza o ícone inicial dos botões
    updateThemeButtons(currentTheme);


    // --- INICIALIZAÇÃO DE COMPONENTES (SWIPER) ---
    if (document.querySelector('.category-swiper')) {
        const categorySwiper = new Swiper('.category-swiper', {
            slidesPerView: 'auto', spaceBetween: 10,
            navigation: { nextEl: '.swiper-button-next', prevEl: '.swiper-button-prev' },
        });
    }

    // --- LÓGICA DOS FORMULÁRIOS ---
    if (signupForm) {
        signupForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const fullname = document.getElementById('fullname').value;
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm-password').value;
            if (password !== confirmPassword) { showMessage(signupForm, 'As senhas não coincidem!', 'error'); return; }
            try {
                const res = await fetch('/register', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ fullname, email, password }), });
                const data = await res.json();
                if (res.ok) { showMessage(signupForm, data.message, 'success'); signupForm.reset(); setTimeout(() => window.location.href = '/login.html', 2000); }
                else { showMessage(signupForm, data.message, 'error'); }
            } catch (error) { showMessage(signupForm, 'Ocorreu um erro na comunicação com o servidor.', 'error'); }
        });
    }

    if (loginForm) {
        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            try {
                const res = await fetch('/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password }), });
                const data = await res.json();
                if (res.ok) { showMessage(loginForm, data.message, 'success'); if (data.redirectUrl) { setTimeout(() => { window.location.href = data.redirectUrl; }, 1500); } }
                else { showMessage(loginForm, data.message, 'error'); }
            } catch (error) { showMessage(loginForm, 'Ocorreu um erro na comunicação com o servidor.', 'error'); }
        });
    }

    if (offerForm) {
        offerForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(offerForm);
            try {
                const res = await fetch('/api/offers', { method: 'POST', body: formData, });
                const data = await res.json();
                if (res.ok) {
                    showMessage(offerForm, data.message, 'success');
                    offerForm.reset();
                    const imagePreviewContainer = document.getElementById('image-preview');
                    const imagePreviewImage = imagePreviewContainer?.querySelector(".image-preview__image");
                    const imagePreviewDefaultText = imagePreviewContainer?.querySelector(".image-preview__default-text");
                    if (imagePreviewDefaultText && imagePreviewImage) { imagePreviewDefaultText.style.display = null; imagePreviewImage.style.display = null; imagePreviewImage.setAttribute("src", ""); }
                } else { showMessage(offerForm, data.message, 'error'); }
            } catch (error) { showMessage(offerForm, 'Ocorreu um erro na comunicação com o servidor.', 'error'); }
        });
    }

    // --- LÓGICA DO FORMULÁRIO DE CONTA ---
    const loadAccountDetails = async () => {
        if (!accountForm) return;
        try {
            const res = await fetch('/api/account');
            if (!res.ok) { showMessage(accountForm, 'Erro ao carregar seus dados.', 'error'); return; }
            const user = await res.json();
            document.getElementById('fullname').value = user.fullname;
            document.getElementById('email').value = user.email;
        } catch (error) { showMessage(accountForm, 'Erro de conexão ao carregar dados.', 'error'); }
    };
    
    if (accountForm) {
        accountForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const fullname = document.getElementById('fullname').value;
            const email = document.getElementById('email').value;
            try {
                const res = await fetch('/api/account', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ fullname, email }) });
                const data = await res.json();
                if (res.ok) { showMessage(accountForm, data.message, 'success'); if (document.querySelector('.welcome-message')) { document.querySelector('.welcome-message').textContent = `Olá, ${data.user.fullname}!`; } }
                else { showMessage(accountForm, data.message, 'error'); }
            } catch (error) { showMessage(accountForm, 'Erro de conexão ao salvar.', 'error'); }
        });
    }

    if (passwordForm) {
        passwordForm.addEventListener('submit', (e) => { e.preventDefault(); showMessage(passwordForm, 'Função de alterar senha ainda não implementada.', 'error'); });
    }

    // Preview Imagem Perfil
    const profilePicUpload = document.getElementById('profile-pic-upload');
    const profilePicPreview = document.getElementById('profile-pic-preview');
    if (profilePicUpload && profilePicPreview) {
        profilePicUpload.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = (event) => { profilePicPreview.src = event.target.result; }
                reader.readAsDataURL(file);
                alert('Preview da imagem atualizado! A lógica de upload para o servidor ainda será implementada.');
            }
        });
    }

    // Preview Imagem Oferta
    const offerImageInput = document.getElementById('offer-image');
    const imagePreviewContainer = document.getElementById('image-preview');
    if(offerImageInput && imagePreviewContainer) {
        const imagePreviewImage = imagePreviewContainer.querySelector(".image-preview__image");
        const imagePreviewDefaultText = imagePreviewContainer.querySelector(".image-preview__default-text");
        offerImageInput.addEventListener("change", function() {
            const file = this.files[0];
            if (file) {
                const reader = new FileReader();
                imagePreviewDefaultText.style.display = "none"; imagePreviewImage.style.display = "block";
                reader.addEventListener("load", function() { imagePreviewImage.setAttribute("src", this.result); });
                reader.readAsDataURL(file);
            } else { imagePreviewDefaultText.style.display = null; imagePreviewImage.style.display = null; imagePreviewImage.setAttribute("src", ""); }
        });
    }

    // --- FUNÇÕES DE BUSCA DE DADOS (FETCH) ---
    const fetchAndDisplayOffers = async () => {
        const offersListDiv = document.getElementById('offers-list');
        if (!offersListDiv) return;
        try {
            const res = await fetch('/api/offers');
            const offers = await res.json();
            if (!res.ok) { offersListDiv.innerHTML = '<p>Erro ao carregar as ofertas.</p>'; return; }
            if (offers.length === 0) {
                offersListDiv.innerHTML = `
                    <div class="offer-card placeholder"><div class="placeholder-img"></div><div class="placeholder-text"></div><div class="placeholder-text short"></div></div>
                    <div class="offer-card placeholder"><div class="placeholder-img"></div><div class="placeholder-text"></div><div class="placeholder-text short"></div></div>
                    <div class="offer-card placeholder"><div class="placeholder-img"></div><div class="placeholder-text"></div><div class="placeholder-text short"></div></div>
                `; return;
            }
            offersListDiv.innerHTML = '';
            offers.forEach(offer => {
                const offerLink = document.createElement('a');
                offerLink.href = `/offer.html?id=${offer.id}`; offerLink.className = 'offer-card-link'; offerLink.style.textDecoration = 'none';
                offerLink.innerHTML = `<div class="offer-card"><span class="offer-type offer-type-${offer.offer_type}">${offer.offer_type}</span><h3>${offer.title}</h3><p>${offer.description || 'Clique para ver mais detalhes...'}</p><div class="author">Publicado por: <strong>${offer.author_name}</strong></div></div>`;
                offersListDiv.appendChild(offerLink);
            });
        } catch (error) { console.error("Erro no fetch das ofertas:", error); offersListDiv.innerHTML = '<p>Erro ao conectar com o servidor.</p>'; }
    };

    const fetchOfferDetails = async () => {
        const offerDetailContainer = document.getElementById('offer-detail-container');
        if (!offerDetailContainer) return;
        const urlParams = new URLSearchParams(window.location.search);
        const offerId = urlParams.get('id');
        if (!offerId) { offerDetailContainer.innerHTML = '<h1 style="text-align: center;">Erro: ID da oferta não fornecido.</h1>'; return; }
        try {
            const res = await fetch(`/api/offers/${offerId}`);
            const offer = await res.json();
            if (!res.ok) { offerDetailContainer.innerHTML = `<h1 style="text-align: center;">Erro: ${offer.message}</h1>`; return; }
            const formattedDate = new Date(offer.created_at).toLocaleDateString('pt-BR', { day: '2-digit', month: 'long', year: 'numeric' });
            const imageHtml = offer.image_url ? `<img src="${offer.image_url}" alt="${offer.title}">` : `<div class="no-image">Sem imagem disponível</div>`;
            offerDetailContainer.innerHTML = `<div class="offer-image-section">${imageHtml}</div> <div class="offer-info-section"> <span class="offer-type offer-type-${offer.offer_type}">${offer.offer_type}</span> <h1>${offer.title}</h1> <p class="description">${offer.description || 'Nenhuma descrição detalhada fornecida.'}</p> <div class="seller-info-box"> <h3>Informações do Vendedor</h3> <p>Publicado por: <strong>${offer.author_name}</strong></p> <p>Data de publicação: ${formattedDate}</p> <a href="mailto:${offer.author_email}" class="contact-button">Entrar em Contato</a> </div> </div>`;
        } catch (error) { console.error('Erro ao buscar detalhes da oferta:', error); offerDetailContainer.innerHTML = '<h1 style="text-align: center;">Erro ao conectar com o servidor.</h1>'; }
    };

    const fetchMyOffers = async () => {
        const myOffersListDiv = document.getElementById('my-offers-list');
        if (!myOffersListDiv) return;
        try {
            const res = await fetch('/api/my-offers');
            const offers = await res.json();
            if (offers.length === 0) { myOffersListDiv.innerHTML = '<p>Você ainda não publicou nenhuma oferta.</p>'; return; }
            myOffersListDiv.innerHTML = '';
            offers.forEach(offer => {
                const card = document.createElement('div');
                card.className = 'offer-card';
                card.innerHTML = `<span class="offer-type offer-type-${offer.offer_type}">${offer.offer_type}</span><h3>${offer.title}</h3><p>${offer.description || ''}</p><div class="card-actions"><button class="delete-btn" data-id="${offer.id}">Excluir</button></div>`;
                myOffersListDiv.appendChild(card);
            });
        } catch (error) { myOffersListDiv.innerHTML = '<p>Erro ao carregar suas ofertas.</p>'; }
    };

    const updateUserNav = async () => {
        const authLinksContainer = document.getElementById('auth-links-container');
        if (!authLinksContainer) return;
        try {
            const res = await fetch('/api/auth/status');
            const data = await res.json();
            if (data.loggedIn) {
                authLinksContainer.innerHTML = `<span class="welcome-message">Olá, ${data.user.fullname}!</span><a href="/create-offer.html" class="auth-link">Criar Oferta</a><a href="/my-offers.html" class="auth-link">Minhas Ofertas</a><a href="/account.html" class="auth-link">Minha Conta</a><a href="/logout" class="auth-link">Sair</a>`;
            } else {
                authLinksContainer.innerHTML = `<a href="/login.html" class="auth-link">Login</a><a href="/index.html" class="auth-link">Cadastro</a>`;
            }
        } catch (error) {
            console.error('Erro ao verificar status de autenticação:', error);
            authLinksContainer.innerHTML = `<a href="/login.html" class="auth-link">Login</a><a href="/index.html" class="auth-link">Cadastro</a>`;
        }
    };

    // --- EVENT LISTENER GLOBAL ---
    document.body.addEventListener('click', async (e) => {
        if (e.target.classList.contains('delete-btn')) {
            const offerId = e.target.getAttribute('data-id');
            if (confirm('Tem certeza que deseja excluir esta oferta? Esta ação não pode ser desfeita.')) {
                try {
                    const res = await fetch(`/api/offers/${offerId}`, { method: 'DELETE' });
                    const data = await res.json();
                    if (res.ok) { alert(data.message); fetchMyOffers(); }
                    else { alert(`Erro: ${data.message}`); }
                } catch (err) { alert('Erro de comunicação com o servidor.'); }
            }
        }
    });

    // --- LÓGICA DO MENU HAMBÚRGUER ---
    const hamburger = document.getElementById('hamburger-menu');
    const sideMenu = document.getElementById('side-menu');
    const menuOverlay = document.getElementById('menu-overlay');
    if (hamburger && sideMenu && menuOverlay) {
        hamburger.addEventListener('click', () => { sideMenu.classList.add('open'); menuOverlay.classList.add('open'); });
        const closeMenu = () => { sideMenu.classList.remove('open'); menuOverlay.classList.remove('open'); };
        menuOverlay.addEventListener('click', closeMenu);
    }
    
    // --- CORREÇÃO DOS LINKS "VOLTAR" ---
    if (document.getElementById('my-offers-list') || document.getElementById('offer-form') || document.getElementById('account-form')) {
        const backLink = document.querySelector('.back-link');
        if(backLink) backLink.href = "/home.html";
    }

    // --- CHAMADA DAS FUNÇÕES AO CARREGAR A PÁGINA ---
    updateUserNav();
    fetchAndDisplayOffers();
    fetchOfferDetails();
    fetchMyOffers();
    loadAccountDetails();
});